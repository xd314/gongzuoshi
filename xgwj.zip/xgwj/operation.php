<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
//define('PROMPT','优化中...');
const PROMPT = '优化中...';
if(strlen($_COOKIE['s'])>32) {
//$_GET['fun']是函数名。
	if (!empty($_POST['fun'])) {
		$_GET['fun'] = $_POST['fun'];
	}
	$fun = $_GET['fun'];
	$fun($_POST['p'], $_POST, $_GET);
}else{
	echo json_encode(array('prompt'=>'PleaseLogIn'));
}

//获取挖机注册用户信息
function wjZHCYH($p=0,$post=array(),$get=array()){
	$mysql_xd314=new  mysql_xd314;
	if($post['type']==''&&$post['time']==''&&$post['dailishang']==''){$where="";}else{
		$where=" WHERE user_id>0 ";
		if($post['time']!=''){$where=$where." AND regtime<".strtotime($post['time']);}
		if($post['type']!=''){$where=$where." AND status='".$post['type']."'";}
		if($post['dailishang']!=''){$where=$where." AND shop_id=".$post['dailishang'];}
	}
	$sysuser_account= $mysql_xd314->search('sysuser_user',$where);
	$listnumber=count($sysuser_account);
	$page = page($p, $listnumber);
	$sysuser_account = $mysql_xd314->search('sysuser_user', $where." ORDER BY regtime DESC  LIMIT " . $page[0] . "," . $page[1]);
	$array1 = [];
	foreach ($sysuser_account as $key => $value) {
		$array2 = [];
		$account = $mysql_xd314->search('sysuser_account', " WHERE user_id=".$value['user_id'])[0];
		$shop = $mysql_xd314->search('sysshop_shop', " WHERE shop_id=".$value['shop_id'])[0];

		$array2['user_id'] = $value['user_id'];
		$array2['mobile'] = $account['mobile'];
		$array2['shop_id'] = $shop['shop_id'];
		$array2['shop_name'] = $shop['shop_name'];
		$array2['regtime'] = date('Y-m-d',$account['createtime']);
		$array2['ex_open_id'] =$value['ex_open_id'];


		$array1[$key] = $array2;

	}
	echo json_encode(array('data' => $array1, 'data1' => $page[3], 'data2' => $p,'listnumber'=>$listnumber,'prompt'=>$_COOKIE));
}

//获取挖机订单信息
function wjZDINGDAN($p=0,$post=array(),$get=array())
{
	$mysql_xd314=new  mysql_xd314;
	if(empty($post['tid'])){
		echo json_encode(array('prompt'=>'Parameters are missing'));
	}else {
		$systrade_order = $mysql_xd314->search('systrade_order', " WHERE tid=".$post['tid']);
		$listnumber=count($systrade_order);
		$page = page($p, $listnumber);
		$systrade_order= $mysql_xd314->search('systrade_order', " WHERE tid=".$post['tid']." ORDER BY oid DESC  LIMIT " . $page[0] . "," . $page[1]);
		$array1 = [];

		foreach($systrade_order as $key=>$value) {
			$array2['tid']=$value['tid'];
			$array2['title']=$value['title'];
			$array2['price']=$value['price'];
			$array2['status']=getTradeStatus($value['status']);
			$array2['num']=$value['num'];
			$array1[$key]=$array2;
		}

		echo json_encode(array('data' => $array1,'data1' =>$page[3], 'data2'=>$p,'title' =>'订单详情','listnumber'=>$listnumber,'prompt'=>PROMPT));
	}
}

//获取挖机订单信息
function wjDINGDAN($p=0,$post=array(),$get=array())
{
	$mysql_xd314 = new  mysql_xd314;
if($post['type']==''&&$post['time']==''&&$post['dailishang']==''){$where="";}else{
	$where=" WHERE tid>0 ";
	if($post['time']!=''){$where=$where." AND created_time<".strtotime($post['time']);}
	if($post['type']!=''){$where=$where." AND status='".$post['type']."'";}
	if($post['dailishang']!=''){$where=$where." AND shop_id=".$post['dailishang'];}
}

	$systrade_trade = $mysql_xd314->search('systrade_trade',$where);
	$listnumber=count($systrade_trade);
	$page = page($p, $listnumber);
	$systrade_trade = $mysql_xd314->search('systrade_trade',$where."  ORDER BY created_time DESC  LIMIT " . $page[0] . "," . $page[1]);
	$array1 = [];
	foreach ($systrade_trade as $key => $value) {
		$array2 = [];
		$sysshop_shop = $mysql_xd314->search('sysshop_shop', " WHERE shop_id=".$value['shop_id'])[0];

		$array2['tid'] = $value['tid'];
		$array2['itemnum'] = $value['itemnum'];
		$array2['payment'] = $value['payment'];
		$array2['receiver_mobile'] = $value['receiver_mobile'];
		$array2['status'] =getTradeStatus($value['status']);
		$array2['shop_name'] = $sysshop_shop['shop_name'];
		$array2['shop_id'] = $sysshop_shop['shop_id'];
		$array2['created_time'] = date('Y-m-d h:s',$value['created_time']);


		$array1[$key] = $array2;
	}
	echo json_encode(array('data' => $array1,'data1' =>$page[3], 'data2'=>$p,'title' => $sysshop['shop_name'],'listnumber'=>$listnumber,'prompt'=>PROMPT));
}



//挖机服务商派单数据
function wjFpaidan($p=0,$post=array(),$get=array()){
	$mysql_xd314=new  mysql_xd314;
	if(empty($post['did'])){
		echo json_encode(array('prompt'=>'Parameters are missing'));
	}else {
		$xg_order = $mysql_xd314->search('xg_order', " WHERE agent_id=".$post['did']);
		$listnumber=count($xg_order);
		$page = page($p, $listnumber);
		$xg_order = $mysql_xd314->search('xg_order', " WHERE agent_id=".$post['did']." ORDER BY id DESC  LIMIT " . $page[0] . "," . $page[1]);
		$sysshop= $mysql_xd314->search('sysshop_shop', " WHERE shop_id=".$post['did'])[0];
		$array1 = [];
		$statu=['0'=>'待接单','1'=>'已接单','2'=>'已拒单','3'=>'订单已取消'];
		foreach ($xg_order as $key => $value) {
			$systrade_trade= $mysql_xd314->search('systrade_trade', " WHERE tid=".$value['tid'])[0];
			$array2['tid']=$value['tid'];
			$array2['receiver_mobile']=$systrade_trade['receiver_mobile'];
			$array2['create_time_for']=$value['create_time_for'];
			$array2['status']=$statu[$value['status']];
			if(empty($sysstrade_strade['payment'])) {
				$array2['jine']=$systrade_trade['payment'];
			}else{
				$array2['jine']=0.00;
			}
			$array1[$key]=$array2;
		}

		echo json_encode(array('data' => $array1,'data1' =>$page[3], 'data2'=>$p,'title' => $sysshop['shop_name'],'listnumber'=>$listnumber,'prompt'=>PROMPT));
	}
}



//获取挖机服务商信息
function wjFWSH($p=0,$post=array(),$get=array()){
$mysql_xd314=new  mysql_xd314;
	$shopall = $mysql_xd314->search('sysshop_shop', "");
	$listnumber=count($shopall);
	$page = page($p, $listnumber);
	$shop = $mysql_xd314->search('sysshop_shop', " ORDER BY shop_id ASC  LIMIT " . $page[0] . "," . $page[1]);
	$array1 = [];
	foreach ($shop as $key => $value) {
		$array2 = [];

		$user = $mysql_xd314->search('sysuser_user', " WHERE shop_id=" . $value['shop_id']);
		$paidan = $mysql_xd314->search('xg_order', " WHERE agent_id=" . $value['shop_id']);
		$dingdan = $mysql_xd314->search('systrade_trade', " WHERE shop_id=" . $value['shop_id']);

		$array2['dailishangid'] = $value['shop_id'];
		$array2['dailishang'] = $value['shop_name'];
		$array2['userN'] = count($user);
		$array2['paidanN'] = count($paidan);
		$array2['dingdanN'] = count($dingdan);
		$array2['shop_type'] = $value['shop_type'];
		$array2['mobile'] = $value['mobile'];

		$array1[$key] = $array2;

	}
	echo json_encode(array('data' => $array1, 'data1' => $page[3], 'data2' => $p,'listnumber'=>$listnumber,'prompt'=>PROMPT));
}




//获取订单状态
function getTradeStatus($status){
	$status1=[
		'TRADE_CLOSED_BY_SYSTEM'=>'订单已关闭',
		'WAIT_SELLER_SEND_GOODS'=>'等待发货',
		'WAIT_BUYER_CONFIRM_GOODS'=>'等待顾客确认收货',
		'TRADE_FINISHED'=>'订单已完成',
		'WAIT_BUYER_PAY'=>'等待顾客支付',
		'TRADE_CLOSED_BEFORE_PAY'=>'在支付之前关闭'
	];
	if(empty($status1[$status])){
		return $status;
	}else {
		return $status1[$status];
	}
}

//通过页数获取数据号
function page($n,$all=0){
$dw=200;
return array($n*$dw,$dw,$n*$dw+$dw,ceil($all/$dw));//开始号，每页条数，结束号，总页数。
}

function RemoveSpaceslinebreaks($str){ $qian=array(" "," ","\t","\n","\r"); return str_replace($qian, '', $str); }
?>
