<?php
class mysql_xd314{//-----系统核心文件（用于构建页面和提供数据）

//---------------------------------------------服务器数据库
  private $server_name=""; //数据库服务器名称 
  private $username=""; // 连接数据库用户名 
  private $password=""; // 连接数据库密码 
  private $mysql_database=""; // 数据库的名字  
	public function a($TableName,$operation,$object='*'){//实验
    if(!empty($TableName)){    
      $strsql='SELECT '.$object.' FROM '.$TableName.'  '.$operation;
      $result=$this->implement($strsql);
      $a=array();
      $t=0;
      $row=0;
      
        return $result;
      
       
    }
  }

public function paging(array $data,$pageid,$pageunit){//--------------------------------------分页(输出数组array($dataid,$dataid1$pagecount,$pageunit,$pagecount,$pageid)   参数：$data数据,$pageid页码,$pageunit每页条数  
$datacount=count($data);//总条数
if(empty($pageunit)){
$pageunit=30;//每页条数
}
if(empty($pageid)){
$pageid=0;//每页条数
}
$pagecount=intval($datacount/$pageunit)+1;//总页数
$dataid=$pageid*$pageunit;//开始条号
$dataid1=($pageid+1)*$pageunit;//结束条号
return  array($dataid,$dataid1,$datacount,$pageunit,$pagecount,$pageid);//开始条号，结束条号，总条数，每页条数，总页数,页码
}

  public function increase($TableName,$operation){//-----------------------------------------------------------------------------增加数据($TableName,$operation)
    if(!empty($TableName)){
        $this->filter($operation);
        $strsql='INSERT '.$TableName.' '.$operation;
   $result=$this->implement($strsql);
         return  true;
    }
  }
  public function delete($TableName,$operation){//--------------------------------------------------------------------------------删除数据($TableName,$operation)
    if(!empty($TableName)){
      $this->filter($operation);
      $strsql='DELETE FROM '.$TableName.' '.$operation;
  $result=$this->implement($strsql);
      return  true;
    }
  }
  public function modify($TableName,$operation){//------------------------------------------------------修改数据($TableName,$operation)
    if(!empty($TableName)){
   $this->filter($operation);
      $strsql='UPDATE '.$TableName.' '.$operation;
   $result=$this->implement($strsql);
    return  true;
  }
  }
  public function search($TableName,$operation,$object='*'){//------------------------------------------------------------查找数据($TableName表名,$object查找对象,$operation查找条件)
    if(!empty($TableName)){    
   $this->filter($operation);
    $strsql='SELECT '.$object.' FROM '.$TableName.'  '.$operation;
    $result=$this->implement($strsql);
    $a=array();
    $t=0;
    while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) {
    $a[$t]=$row;
    $t=$t+1;
    }
    return  $a;
     
  }
  }
  
    public function implement($strsql){
    $conn=mysqli_connect($this->server_name,$this->username,$this->password,$this->mysql_database); // 连接到数据库
    mysqli_query($conn,"set names utf8");
    $result=mysqli_query($conn,$strsql); 
    mysqli_close($conn);  
    return  $result;
  }
public function filter($sqlstr){//过滤输入参数
     if(!empty(explode('DELETE',$sqlstr)[1])||!empty(explode('delete',$sqlstr)[1])||!empty(explode('SELECT',$sqlstr)[1])||!empty(explode('select',$sqlstr)[1])||!empty(explode('UPDATE',$sqlstr)[1])||!empty(explode('update',$sqlstr)[1])){exit(true);}
  }
}
?>
