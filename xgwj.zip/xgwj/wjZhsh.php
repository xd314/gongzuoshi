<?php
/*
/xgwj/wjZhsh.php?uid=1819&time=12345678987&token=234567

*/
require_once("class/mysql_xd314.php");$mysql_xd314=NEW mysql_xd314;
$signatur='c11257a8ad328acc17edac5357a13fec';$uid=$_GET['uid'];$time=$_GET['time'];$token=$_GET['token'];
//$all1='151637159554145121212e7db055b9818e0ad0649d9d3a76b10dc';
//$token2=MD5($all1);
if(empty($uid)||empty($time)||empty($token)){
$output=json_encode(['prompt'=>'Missing parameter or parameter name error!']);
}else{
$user_account=$mysql_xd314->search('sysuser_account'," WHERE user_id=".$uid)[0];

if(empty($user_account['user_id'])){
$output=json_encode(['prompt'=>'No such user!']);
}else{
$user_user=$mysql_xd314->search('sysuser_user'," WHERE user_id=".$uid)[0];
$shop=$mysql_xd314->search('sysshop_shop'," WHERE shop_id=".$user_user['shop_id'])[0];
$all=$user_account['user_id'].$time.$signatur;
$token1=MD5($all);
if($token1==$token){
$output=json_encode(['userinfo'=>['openid'=>$user_user['ex_open_id'],'username'=>$user_account['login_account'],'mobile'=>$user_account['mobile'],'dealerid'=>$shop['shop_id'],'dealername'=>$shop['shop_name'],'sex'=>$user_user['sex'],'province'=>'','city'=>'','county'=>$user_user['area'],
'address'=>$user_user['addr']],'prompt'=>'success']
);
}else{
$output=json_encode(['prompt'=>'Token error!']);
}
}

}
echo $output;

